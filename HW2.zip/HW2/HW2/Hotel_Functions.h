#pragma once
#ifndef __HOTEL_FUNC
#define __HOTEL_FUNC 

#pragma warning(disable: 4996)
#include <stdio.h>
#include "Hotel_Structs.h"
#include <string.h>
#include <conio.h>


#define START_ID 1

// checkIn errors
#define THE_CUSTOMER_ALREADY_EXSISTS -1000
#define USER_DONT_WANT_TO_ADD_CUSTOMER -1001
#define THERE_IS_NOT_AN_EMPTY_ROOM_IN_HOLE_HOTEL -1002
#define CREDIT_NUMBER_IS_NOT_LEGAL -1003
#define CREDIT_VALIDITY_IS_NOT_LEGAL -1004

// dont touch!
#define FALSE 0
#define TRUE 1


// declaration of the methods:

void showHotelStatus(const Hotel_t* hotel);  // 1
int isCreditNumberLegal(const char* creditNum);  // 6
int isCreditValidityLegal(const int creditValMonth, const int creditValYear);  // 6
void transferFromLittleToCapital(const Customer_t* custromerArray, int arrSize);  // 7
Customer_t* addCustomer(char* name, char *creditNum, int creditValMonth, int creditValYear, Super_Struct *director);
void printRoom(Room_t *room);
int isNumOfGuestInRoomLegal(int numOfGuest);
int isNumOfGuestInRoomEatBreakfastLegal(int breakfast);


/*  show the status of all rooms which are contained in hotel */
void showHotelStatus(const Hotel_t* hotel)
{
	int floors = hotel->floors;
	int roomsInFloor = hotel->roomsInFloor;
	Room_t **mat = hotel->roomMatrix;
	int i, j;
	for (i = 0; i < floors; i++)
	{
		printf("\n\nFLOOR %d:\n", i+1);
		for (j = 0; j < roomsInFloor; j++)
		{
			printf("\nRoom %-3d:\n", ((i + 1) * MAX_ROOMS_IN_ONE_FLOOR + j + 1));
			if (mat[i][j].areThereGuests == 1)
			{
				printf("|%-12s|\n", "not empty");
				printf("|%-9s: %d|\n", "Guests", mat[i][j].numOfGuests);
				printf("|%-9s: %d|\n", "Breakfast", mat[i][j].breakfast);
			}
			else
			{
				printf("|%-12s|\n", "empty");
			}
		}
	}
}






/* Add customer */
Customer_t* addCustomer(const char* name, const char *creditNum, const int creditValMonth, const int creditValYear, Super_Struct *director)
{
	static int id = START_ID;  // internal system customer' id

	//static int logicSize = START_LOGIC_ARRAY_SIZE;
	//static int arrSize = START_PYSICAL_ARRAY_SIZE;  // size of 


	if (director->customerArraySize <= director->numOfCustomers)  // if there are more customers than the array can contains:
	{
		//  let's double the size of the array
		director->customerArraySize *= 2;
		director->customerArray = (Customer_t*)realloc(director->customerArray, director->customerArraySize * sizeof(Customer_t));
	}

	int index = director->numOfCustomers;
	Customer_t* cPointer = director->customerArray;
	// savings
	cPointer[index].id = id;  // id 
	cPointer[index].name = (char*)calloc(strlen(name), sizeof(char));  // name
	strcpy(cPointer[index].name, name);  
	cPointer[index].creditNum = (char*)calloc(CREDIT_CARD_LENGTH, sizeof(char));
	strcpy(cPointer[index].creditNum, creditNum);  // credit number
	cPointer[index].creditValMonth = creditValMonth;  // cradit month is saved
	cPointer[index].creditValYear = creditValYear;  // cradit year is saved

	//end:
	id++;
	(director->numOfCustomers)++;
	return cPointer + index;
}



// TODO add reservatrion method




/*Print all information about a spesific room*/
void printRoom(Room_t *room)
{
	if (room->areThereGuests == FALSE) 
	{
		printf("The room is empty.\n");
	}
	else
	{
		printf("The room is rented!\n");
	}
	printf("Number of guests: %d", room->numOfGuests);
	printf("Number of guests who allow to eat breakfast: %d", room->breakfast);
}


// 6.A
/* Check customer' credit' number. if 'creditNum' is legal, return 1. Else 0*/
int isCreditNumberLegal(const char* creditNum)
{
	int i;
	char currenrChar;
	for (i = 0; i < CREDIT_CARD_LENGTH; i++)
	{
		currenrChar = creditNum[i];
		if (currenrChar < '0' || currenrChar > '9')  // if temp is not a digit
		{
			return FALSE;
		}
	}
	// All chars are digits:
	return TRUE;
}


// 6.B
/* Check customer' credit' validity. If the validity is legal it returns 1. Else, 0 */
int isCreditValidityLegal(const int creditValMonth, const int creditValYear)
{
	if ((creditValMonth < MIN_MONTH || creditValMonth > MAX_MONTH)
		|| (creditValYear < MIN_YEAR || creditValMonth > MAX_YEAR))
	{
		return FALSE;
	}
	return TRUE;
}


// 7
/* Transfer from little letters to capital letters*/
void transferFromLittleToCapital(const Customer_t* custromerArray, int arrSize)
{
	int i;
	//Customer_t* pointer = custromerArray;
	char* currentName;
	for (i = 0; i < arrSize; i++)
	{
		currentName = custromerArray[i].name;
		if (*currentName >= 'a' && *currentName <= 'z')
		{
			currentName[0] -= 32;
		}
	}
}


// 8 
/* seif 8 */
/*
Customer_t* getAllCustomerWithString(const char* string, const Customer_t* custromerArray)
{
	char* stringPointer = string;

}
*/



/*if checkIn was suc*/
int checkIn(Super_Struct *director)
{
	/* -Print all the Customers in the system.
	   -The user write a name of customer.
	   -If the customer' name exist, continue the program
	   else, ask the user if he wants to add him to the system.
	   The method check if there is an empty room.
	   if it founds one, the method print the exact room' and the user may write the information about the customer:
	   num of guests, num of guests who allow to eat breakfast.
	   It calls to addCustomer for adding details about the customer. 
	   The method add the current reservatrion to the array of reservatrions
	*/
	printf("\nList of all customers of %s Hotel\n", director->hotelName);
	int i;
	Customer_t* cArray = director->customerArray;
	for (i = 0; i < director->numOfCustomers; i++)
	{
		printf("%d) %s\n", i+1, cArray[i].name);
	}
	printf("\nPlease enter a name: ");
	char* chosenName = (char*)malloc(30 * sizeof(char));
	scanf("%s", chosenName);

	int isEqual = -1;
	i = 0;
	int limit = director->numOfCustomers;
	while (i < limit && isEqual != 0)
	{
		isEqual = strcmp(chosenName, cArray[i].name);  // 0 = ARE EQUAL
		i++;
	}

	if (isEqual == 0)  // the customer already exsists
	{
		printf("The customer already exist, and his number is %d\n", i+1);
		return THE_CUSTOMER_ALREADY_EXSISTS;
	}
	char isTheUserWantToAddCustomer;
	printf("The customer doesn't exists. Do you want to add him? (y/n): ");
	isTheUserWantToAddCustomer = getche();
	while (isTheUserWantToAddCustomer != 'y' || isTheUserWantToAddCustomer != 'n')
	{
		printf("Please choose one of the options (y/n): ");
		isTheUserWantToAddCustomer = getche();
	}
	if (isTheUserWantToAddCustomer == 'n')
	{
		return USER_DONT_WANT_TO_ADD_CUSTOMER;
	}

	// The user want to continue and add the customer
	// found empty 
	int isThereAnEmptyRoom = FALSE;
	int roomIndex = 0;
	int floors = director->hotel->floors;
	int totalNumRooms = (floors) * (director->hotel->roomsInFloor);
	Room_t* roomPointer;
	while (roomIndex < totalNumRooms && isThereAnEmptyRoom == FALSE)
	{
		roomPointer = (director->hotel->roomMatrix)[roomIndex/floors] + roomIndex%floors;
		if (roomPointer->areThereGuests == FALSE)  // there are no guests in this room
		{
			isThereAnEmptyRoom = TRUE;
		}
		else
		{
			roomIndex++;
		}
	}
	if (isThereAnEmptyRoom == FALSE)
	{
		return THERE_IS_NOT_AN_EMPTY_ROOM_IN_HOLE_HOTEL;
	}

	//There is an empty room
	// fill the room of the system:
	// we know "roomIndex" in the matrix
	int numOfGuest, breakfast;
	do
	{
		printf("Please enter num of guests in room (%d-%d)\n:", MIN_GUESTS_IN_ONE_ROOM, MAX_GUESTS_IN_ONE_ROOM);
		scanf("%1d/n", numOfGuest);
	} while (isNumOfGuestInRoomLegal(numOfGuest) == FALSE);
	do
	{
		printf("Please enter num of guests in breakfast (%d-%d):\n", MIN_GUESTS_HAVE_BREAKFAST, MAX_GUESTS_HAVE_BREAKFAST);
		scanf("%1d\n", breakfast);
	} while (isNumOfGuestInRoomEatBreakfastLegal(breakfast) == FALSE);
	roomPointer->areThereGuests = TRUE;
	roomPointer->numOfGuests = numOfGuest;
	roomPointer->breakfast = breakfast;
	
	//TODO add the customer to the system:
	char* name = chosenName, *creditNum;
	int month, year;
	Customer_t* customerPointer;
	do
	{
		printf("Please enter credit number (must be %d digits):\n", CREDIT_CARD_LENGTH);
		scanf("%s", );  //TODO
	} while (isCreditNumberLegal(creditNum) == FALSE);
	
	printf("Please enter credit validity (month and year, WITHOUT spaces, dots or any character that isn't digit):\n");
	printf("For example: 11.2011  --->  112011\n");
	scanf("%2d%4d\n", month, year);  
	while (isCreditValidityLegal(month, year) == FALSE)
	{
		printf("the month must be between %d to %d\n", MIN_MONTH, MAX_MONTH);
		printf("and the year must be between %d to %d\n", MIN_YEAR, MAX_YEAR);
		scanf("%2d%4d\n", month, year);  
	}

	// add the customer
	customerPointer = addCustomer(name, creditNum, month, year, director);
		/*

		if (isCreditValidityLegal(creditValMonth, creditValYear) == FALSE)
		{
			return CREDIT_VALIDITY_IS_NOT_LEGAL;
		}
		*/
		


	//TODO add a reservation to the array:
}


// HELP method - check if naumber of guests per room is legal
int isNumOfGuestInRoomLegal(int numOfGuest)
{
	if (numOfGuest < MIN_GUESTS_IN_ONE_ROOM || numOfGuest > MAX_GUESTS_IN_ONE_ROOM)
	{
		return FALSE;
	}
	return TRUE;
}


// HELP method - check if naumber of guests per room that can eat breakfast is legal
int isNumOfGuestInRoomEatBreakfastLegal(int breakfast)
{
	if (breakfast < MIN_GUESTS_HAVE_BREAKFAST || breakfast > MAX_GUESTS_HAVE_BREAKFAST)
	{
		return FALSE;
	}
	return TRUE;
}








#endif // __HOTEL_FUNC